﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DeviceTesterCore.Interfaces;
using Moq;
using NUnit.Framework.Legacy;
using NUnit.Framework;
using DeviceTesterCore.Models;
using System.Collections.ObjectModel;

namespace DeviceTesterTests.ViewModelTests
{
    [TestFixture]
    public class DeviceViewModelTests
    {

    }
}
