﻿namespace DeviceTesterTests
{
    public class Class1
    {

    }
}
