﻿namespace DeviceTesterCore
{
    public class Class1
    {

    }
}
