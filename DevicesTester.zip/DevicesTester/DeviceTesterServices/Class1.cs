﻿namespace DeviceTesterServices
{
    public class Class1
    {

    }
}
